@JS()
// 宣告此為程式庫 ,名稱為 cango
library cango;
// 此程式庫需要導入 package 中的 js 程式庫
import 'package:js/js.dart';

@JS()
class Cango {
  // Cango 為外部程式庫, 在此轉為 Dart 類別
  external factory Cango(String selector);
  // 以下為 Cango 在外部程式庫的相關方法, 在此轉為 Dart Cango 類別的物件方法
  external dynamic gridboxPadding(int left, int bottom, int right, int top);
  external dynamic setWorldCoordsRHC(num vpOriginX, num vpOriginY, num spanX, num spanY);
  external dynamic drawAxes(num xMin, num xMax, num yMin, num yMax, Map options);
  external dynamic drawPath(List pathDef, Map options);
  external dynamic render(var rootObj);
  external dynamic circle(num diameter);
  external dynamic ellipse(num width, num height);
  external dynamic square(num width);
  external dynamic rectangle(num width, num height, num rad);
  external dynamic  triangle(num side);
  external dynamic cross(num width);
  external dynamic ex(num diagonal);
}
external dynamic clone(var orgItem);
external dynamic SVGpath(String pathStr);

@JS()
class Path{
external factory Path(var commands, var options);
external dynamic dup();
}


@JS()
class SVGsegs{
    external factory SVGsegs(var data);
    external toString();
    external dynamic dup();
    external dynamic translate(num x, num y);
    external dynamic rotate(num deg);
    external dynamic appendPath(var extensionData);
    external dynamic joinPath(var extensionData);
}

// 以下為從 html Javascript 程式導入, 直接在此轉為 Dart 函式或變數宣告
external dynamic createGearTooth(num module, int teeth, num pressureAngle);
external dynamic rotateTooth(List inData, num rotRads);
external dynamic Tweener(num delay, num duration, String loopStr);
