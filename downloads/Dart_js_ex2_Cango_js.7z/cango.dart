@JS()
library cango;
import 'package:js/js.dart';

@JS()
class Cango {
  external factory Cango(String selector);
  external dynamic gridboxPadding(int left, int bottom, int right, int top);
  external dynamic setWorldCoordsRHC(num vpOriginX, num vpOriginY, num spanX, num spanY);
  external dynamic drawAxes(num xMin, num xMax, num yMin, num yMax, Map options);
  external dynamic drawPath(List pathDef, Map options);
}