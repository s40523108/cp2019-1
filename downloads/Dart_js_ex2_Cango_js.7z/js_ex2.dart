import './cango.dart';

import 'dart:html';
import 'dart:core';
import 'dart:math' as math;
import 'package:js/js.dart';

CanvasElement canvas;
CanvasRenderingContext2D ctx;

main() {
  var cgo = Cango("canvas");
  num i;
  List data = [];
  cgo.gridboxPadding(10, 10, 10, 10);
  cgo.setWorldCoordsRHC(0, -50, 2 * math.pi, 100);
  // draw axes

  cgo.drawAxes(0, 6.5, -50, 50,
      {'xOrigin': 0, 'yOrigin': 0, 'fontSize': 10, 'strokeColor': 'gray'});

  for (i = 0; i <= 2 * math.pi; i += 0.03) {
    data.add([i, 50 * math.sin(i)]);
  }
  // 配合 Cango 資料結構需求, 在最前方加入 'M'
  data[0] = 'M';
  print(data);
  cgo.drawPath(data, {'strokeColor': 'red'});
}
